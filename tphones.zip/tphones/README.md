# my name is mohmed tony ,i live in egypt
# YourLists: A Shopping store and Todo List Web App
A CS50 Final Project
# Made as a final project for the course CS50's Introduction to Computer Science, Your store helps users manage their shopping lists as well as todo lists
# tphones
#### Video Demo:  https://youtu.be/ZWUrzzUtj0c
## Description:
My final project is a Sudoku Solver Web Application  
A simple web app that can solve 9x9 sudoku game
## Prerequsites
- Make sure you have chorom installed and you use it to run this program.
- You have to make sure you have Flask installed. If not you can use pip or your favourite package manager to install it.
 
------------------------------------------------------------------------------
## How to run
- First you have to install chorom module go back to Documentations section for installtion guide
- In the project directory run link` And open the URL in the browser by default it's ``127.0.0.1:5000`` You can change it by passing optional param ``--host=`` and ``--port=``
- You can reset the board by click ``reset`` button

## Files
- ``/data`` it handles photos
- ``/index.html`` it's reqponsible for the wep
- ``/static/`` it contains all styles and js files of the page
- ``/templates/`` it contains all HTML files of the page  

------------------------------------------------------------------------------
## About CS50
CS50 is a openware course from Havard University and taught by David J. Malan

Introduction to the intellectual enterprises of computer science and the art of programming. This course teaches students how to think algorithmically and solve problems efficiently. Topics include abstraction, algorithms, data structures, encapsulation, resource management, security, and software engineering. Languages include C, Python, and SQL plus students’ choice of: HTML, CSS, and JavaScript (for web development).

Thank you for all CS50.
-----------------------------------------------------------------------------
# Aboat the running
It contains all the latest versions of the iPhone. Once I choose the device and your favorite color, it will give you information from
space
price
and ram
and delivery methods
and customer service
------------------------------------------------------------------------------
# the lectures
Also, I was very happy during the period in which I studied computer science, which was explained by David Malan, who also enjoyed his interesting explanation, which encouraged me to complete this course strongly